package practicabiblioteca;

import model.Biblioteca;
import model.Genero;
import model.Ilustracion;
import model.Libro;
import model.PublicacionRepetidaException;
import model.Revista;

public class PracticaBiblioteca {

    public static void main(String[] args) {
        
        Biblioteca miBiblioteca = new Biblioteca();
        
        cargarBiblioteca(miBiblioteca);
        
        System.out.println(miBiblioteca.mostrarPublicaciones());
        
        System.out.println("---------------------");
        miBiblioteca.leerPublicaciones();
        
    }
    
    public static void cargarBiblioteca(Biblioteca biblioteca){
        
        try{           
            Ilustracion i1 = new Ilustracion("Dibujo de Mafalda", 2017, "Quino", 50, 70);
            //Ilustracion i2 = new Ilustracion("Dibujo de Mafalda", 2017, "Quino", 50, 70);
            Libro l1 = new Libro("1984", 1949, "Orwell", Genero.FICCION);
            Revista r1 = new Revista("Caras", 2014, 4);

            biblioteca.agregarPublicacion(i1);
            //biblioteca.agregarPublicacion(i2);
            biblioteca.agregarPublicacion(l1);
            biblioteca.agregarPublicacion(r1);
            
        }catch(PublicacionRepetidaException error){
            System.out.println(error.getMessage());
        }

        
    }
    
    
}
