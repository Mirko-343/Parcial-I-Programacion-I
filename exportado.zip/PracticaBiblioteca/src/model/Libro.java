package model;

public class Libro extends Publicacion implements Leible{
    
    private String autor;
    private Genero genero;
    
    public Libro(String titulo, int anioPublicacion, String autor, Genero genero){
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }
    
    @Override
    public String leer(){
        return "Leyendo libro " + this.getTitulo();
    }
    
    @Override
    public String toString(){
        return "Libro: {" + formatearToString() + 
                ", Autor: " + this.autor + 
                ", Genero: " + this.genero + 
                "}";
    }

    protected String formatearToString(){
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        return sb.substring(sb.indexOf("{") + 1, sb.indexOf("}"));     
    }
    
}
