package model;

public class PublicacionRepetidaException extends RuntimeException{
    
    private static String MESSAGE = "Publicacion repetida";
    
    public PublicacionRepetidaException(){
        this(MESSAGE);
    }
    
    public PublicacionRepetidaException(String message){
        super(message);
    }
}
