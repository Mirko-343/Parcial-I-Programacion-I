package model;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    
    private ArrayList<Publicacion> publicaciones = new ArrayList<>();
    
    public void agregarPublicacion(Publicacion publicacion){
        if(publicacion != null){
            verificarPublicacionRepetida(publicacion);
            publicaciones.add(publicacion);
        }else{
            throw new NullPointerException("La publicacion no puede ser nula");
        }
    }
    
    public StringBuilder mostrarPublicaciones(){
        if(!publicaciones.isEmpty()){
            StringBuilder sb = new StringBuilder("---------- Publicaciones ----------");          
            for(Publicacion p : publicaciones){
                sb.append("\n");
                sb.append(p.toString());
            }           
            return sb;
        }else{
            return null;
        }

    }
    
    public void leerPublicaciones(){
        for(Publicacion p : publicaciones){
            if(p instanceof Leible x){
                System.out.println(x.leer());
            }else{
                System.out.println("No es posible leer " + p.getTitulo());
            }
        }
    }
    
    
    
    private void verificarPublicacionRepetida(Publicacion publicacion){
        for(Publicacion p : this.publicaciones){
            if(publicacion.equals(p)){
                throw new PublicacionRepetidaException("La publicacion que se quiere agregar ya se encuentra en la lista");
            }
        }
    }
}
