package model;

public class Ilustracion extends Publicacion{
    
    private String ilustrador;
    private double alto;
    private double ancho;
    
    public Ilustracion(String titulo, int anioPublicacion, String ilustrador, double alto, double ancho){
        super(titulo, anioPublicacion);
        this.ilustrador = ilustrador;
        this.alto = alto;
        this.ancho = ancho;
    }

    @Override
    public String toString(){
        return "Ilustracion: {" + formatearToString() +
                ", Ilustrador: " + this.ilustrador +
                ", Alto: " + this.alto +
                ", Ancho: " + this.ancho +
                "}";                        
    }
    
    private String formatearToString(){
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        return sb.substring(sb.indexOf("{") + 1, sb.indexOf("}"));     
    }
    
}
