package model;


public class Revista extends Publicacion implements Leible{
    
    private int edicion;
    
    public Revista(String titulo, int anioPublicacion, int edicion){
        super(titulo, anioPublicacion);
        this.edicion = edicion;
    }
    
    @Override
    public String leer(){
        return "Leyendo revista " + this.getTitulo();
    }
    
    @Override
    public String toString(){
        return "Revista: {" + formatearToString() + 
                ", Edicion: " + this.edicion + 
                "}";
    }
    
    
    protected String formatearToString(){
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        return sb.substring(sb.indexOf("{") + 1, sb.indexOf("}"));     
    }
    
}
