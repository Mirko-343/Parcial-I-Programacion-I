package model;


public interface Leible {
    
    abstract String leer();
    
}
