package model;
import java.util.Objects;

public class Publicacion {
    
    private String titulo;
    private int anioPublicacion;
    
    public Publicacion(String titulo, int anioPublicacion){
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }
    
    public String getTitulo(){
        return this.titulo;
    }
    
    public int getAnioPublicacion(){
        return this.anioPublicacion;
    }
    
    @Override
    public boolean equals(Object o){   
        if(!(o instanceof Publicacion x) || o == null){
            return false;
        }       
        return (x.getTitulo() == this.getTitulo() && x.getAnioPublicacion() == this.anioPublicacion);       
    } 
    
    @Override
    public int hashCode(){
        return Objects.hash(this.titulo, this.anioPublicacion);
    }
    
    @Override
    public String toString(){
        return "Publicacion: {Titulo: " + this.titulo + 
                ", Anio de publicacion: " + this.anioPublicacion +
                "}";
    }
    
}
